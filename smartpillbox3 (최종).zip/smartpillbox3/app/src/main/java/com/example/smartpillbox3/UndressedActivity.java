package com.example.smartpillbox3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class UndressedActivity extends AppCompatActivity {

    private static final String TAG = "AlarmActivity";
    TextView undressed_alarm_text;
    Button undressed_alarm_close;
    MediaPlayer mediaPlayer;
    boolean flag = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_undressed);
        Log.d(TAG, "AlarmActivity");
        //알람액티비티에서 전달해줄 내용 받아온다
        Intent intent = getIntent();
        String type = intent.getExtras().getString("TYPE");
        String userID = intent.getExtras().getString("userID");
        String medi_name = intent.getExtras().getString("medi_name");

        undressed_alarm_close = (Button) findViewById(R.id.undressed_alarm_close);
        undressed_alarm_text = (TextView) findViewById(R.id.undressed_text);
        undressed_alarm_text.setText(userID+"님\n" +type+"의\n"+medi_name+"을 복용하세요!");


        //잠금화면 위로 activity 띄워줌
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
               | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
               | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);

        //알람 재생
        mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.sound2);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();

        //종료버튼
        undressed_alarm_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.stop();
                flag = false;
                finish();

            }
        });


    }
}
