package com.example.smartpillbox3;

public class Actions {
    final static String TO_STAT_ACTIVITY ="TO_STAT_ACTIVITY"; //다른 클래스에서 통계액티비티로 메시지를 보낼때 사용
    final static String TO_CLIENT_SERVICE ="TO_CLIENT_SERVICE"; //다른 클래스에서 클라이언트서비스로 메시지를 보낼때 사용
    final static String TO_MAIN_ACTIVITY="TO_MAIN_ACTIVITY"; //다른 클래스에서 메인액티비티로 메시지를 보낼때 사용

}
