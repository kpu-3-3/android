package com.example.smartpillbox3;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AlarmCheckService extends Service {
    String userID,type,medi_name,b_time,Date;

    public AlarmCheckService() {
    }
    private static final String TAG = "AlarmService";
    private AlarmManager alarmManager; //안드로이드 시스템의 알람 관리자
    private BroadcastReceiver mTimeChangedReceiver; //사용자가 알람 시간을 바꾸는지를 감지하는 리시버

    @Override
    public void onCreate() {//서비스가 처음 실행될 때 호출됨
        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        //사용자가 알람 시간을 바꾸는지 감지하는 리시버 설정 및 등록
        mTimeChangedReceiver = new AlarmChangeReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(AlarmManager.ACTION_NEXT_ALARM_CLOCK_CHANGED);
        registerReceiver(mTimeChangedReceiver, intentFilter);
        super.onCreate();
    }

    //서비스가 시작될 때 호출
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG,"AlarmService");

         userID=intent.getStringExtra("userID");
         type=intent.getStringExtra("type");
         medi_name=intent.getStringExtra("medi_name");
         b_time=intent.getStringExtra("b_time");
         Date=intent.getStringExtra("Date");

        sendMsgToOther(Actions.TO_CLIENT_SERVICE, "sendMsgToServer", type);
        sendMsgToOther(Actions.TO_CLIENT_SERVICE, "saveMsgToServer", userID,type,medi_name,b_time,Date);

        Intent alarmIntent=new Intent(AlarmCheckService.this,AlarmActivity.class);
        //액티비티에 intent를 넘겨줄때 정보를 함께 넘겨줌! -구분할 때 쓰는 기능
        alarmIntent.putExtra("userID", userID); //사용자 이름
        alarmIntent.putExtra("type", type); //사용자가 복용할 타입
        alarmIntent.putExtra("medi_name", medi_name); //사용자의 약 이름
        startActivity(alarmIntent.addFlags(alarmIntent.FLAG_ACTIVITY_NEW_TASK));


        return START_STICKY ;
    }

    //서비스가 종료될 때 호출
    @Override
    public void onDestroy() {
        unregisterReceiver(mTimeChangedReceiver); //리시버 등록 해제
        super.onDestroy();
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent)
    {
        return null;
    }

    private class AlarmChangeReceiver extends BroadcastReceiver
    {
        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(TAG,"sendMsgToServer : 1 send");
            //알람시간에 맞춰서 서비스가 시작되면 서버에 1을 보낸다
            sendMsgToOther(Actions.TO_CLIENT_SERVICE, "sendMsgToServer", "1");
            sendMsgToOther(Actions.TO_CLIENT_SERVICE, "saveMsgToServer", userID,type,medi_name,b_time,Date);

        }
    }
    //다른 클래스의 브로드캐스트 리시버로 메시지를 보내는 함수
    private void sendMsgToOther(String action, String ...msg) {
        Intent intent = new Intent();
        intent.setAction(action);
        intent.putExtra("msg", msg);
        sendBroadcast(intent);
    }
}
